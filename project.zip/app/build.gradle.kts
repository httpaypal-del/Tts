plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.tts2mp3"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.tts2mp3"
        minSdk = 29; targetSdk = 34; versionCode = 1; versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    // Bộ mã hóa MP3 (LAME) cho Android
    implementation("com.github.naman14:TAndroidLame:0.1")
}
