package com.example.tts2mp3

import android.app.Activity
import android.content.ContentValues
import android.os.Bundle
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.widget.*
import com.naman14.androidlame.AndroidLame
import com.naman14.androidlame.LameBuilder
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var rate: SeekBar

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        input = EditText(this).apply { hint = "Nhập văn bản cần đọc..."; minLines = 8; gravity = Gravity.TOP }
        rate = SeekBar(this).apply { max = 20; progress = 5 } // 0.5x .. 2.5x, mặc định 1.0x
        status = TextView(this)
        val play = Button(this).apply { text = "▶ Nghe thử"; setOnClickListener { speak() } }
        val stop = Button(this).apply { text = "■ Dừng"; setOnClickListener { tts.stop() } }
        val save = Button(this).apply { text = "⬇ Lưu thành MP3"; setOnClickListener { saveMp3() } }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40)
            addView(TextView(context).apply { text = "Chuyển văn bản thành giọng nói"; textSize = 20f })
            addView(input); addView(TextView(context).apply { text = "Tốc độ đọc" }); addView(rate)
            addView(play); addView(stop); addView(save); addView(status)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        tts = TextToSpeech(this, this)
    }

    override fun onInit(s: Int) {
        if (s != TextToSpeech.SUCCESS) { status.text = "Không khởi tạo được TTS"; return }
        val r = tts.setLanguage(Locale("vi", "VN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
            status.text = "Thiếu giọng tiếng Việt: vào Cài đặt > Chuyển văn bản thành giọng nói để tải."
    }

    private fun speed() = 0.5f + rate.progress * 0.1f
    private fun ui(msg: String) = runOnUiThread { status.text = msg }
    private fun text() = input.text.toString().trim()

    private fun speak() {
        if (text().isEmpty()) return
        tts.setSpeechRate(speed()); tts.speak(text(), TextToSpeech.QUEUE_FLUSH, null, "play")
    }

    private fun saveMp3() {
        val t = text()
        if (t.isEmpty()) return
        if (t.length >= TextToSpeech.getMaxSpeechInputLength()) {
            ui("Văn bản quá dài (tối đa ${TextToSpeech.getMaxSpeechInputLength()} ký tự mỗi lần)."); return
        }
        val wav = File(cacheDir, "tmp.wav")
        tts.setSpeechRate(speed())
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { ui("Lỗi tạo âm thanh") }
            override fun onDone(id: String?) {
                if (id != "save") return
                Thread {
                    try {
                        val name = "tts_${System.currentTimeMillis()}.mp3"
                        wavToMp3(wav, name)
                        ui("Đã lưu: Music/TTS/$name")
                    } catch (e: Exception) { ui("Lỗi: ${e.message}") }
                }.start()
            }
        })
        ui("Đang tạo MP3...")
        tts.synthesizeToFile(t, null, wav, "save")
    }

    private fun wavToMp3(wav: File, name: String) {
        val data = wav.readBytes()
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val ch = bb.getShort(22).toInt()
        val sr = bb.getInt(24)
        bb.position(44)
        val raw = ShortArray((data.size - 44) / 2).also { bb.asShortBuffer().get(it) }
        // Chuyển về mono (lấy kênh trái nếu là stereo)
        val pcm = if (ch == 2) ShortArray(raw.size / 2) { raw[it * 2] } else raw

        val cv = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/TTS")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv)!!
        val lame: AndroidLame = LameBuilder().setInSampleRate(sr).setOutSampleRate(sr)
            .setOutChannels(1).setOutBitrate(128).build()
        contentResolver.openOutputStream(uri)!!.use { out ->
            val chunk = 8192
            val buf = ByteArray((7200 + chunk * 1.25).toInt())
            var i = 0
            while (i < pcm.size) {
                val part = pcm.copyOfRange(i, minOf(i + chunk, pcm.size))
                val n = lame.encode(part, part, part.size, buf)
                if (n > 0) out.write(buf, 0, n)
                i += chunk
            }
            val n = lame.flush(buf)
            if (n > 0) out.write(buf, 0, n)
        }
        cv.clear(); cv.put(MediaStore.Audio.Media.IS_PENDING, 0)
        contentResolver.update(uri, cv, null, null)
        wav.delete()
    }

    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
