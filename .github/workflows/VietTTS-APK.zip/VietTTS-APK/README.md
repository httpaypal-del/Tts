# Viet TTS – giao diện HTML đóng gói thành APK

- Giao diện: `app/src/main/assets/index.html` (HTML/CSS/JS thuần)
- Vỏ APK: Android WebView (`MainActivity.kt`) + cầu nối `TtsBridge.kt`
  - đọc bằng engine TTS của Android
  - xuất MP3: TextToSpeech.synthesizeToFile -> WAV -> LAME -> MP3 (Music/VietTTS)

## Lấy file APK bằng GitHub Actions (không cần cài gì)
1. Tạo repository mới trên github.com, upload TOÀN BỘ nội dung thư mục này
   (nhớ cả thư mục ẩn `.github`).
2. Vào tab **Actions** > workflow **Build APK** > chờ chạy xong (~3-5 phút).
   Nếu chưa tự chạy: bấm **Run workflow**.
3. Mở lần chạy đã xong, kéo xuống **Artifacts**, tải `VietTTS-apk`, giải nén ra `app-debug.apk`.
4. Chép sang điện thoại, cho phép "Cài ứng dụng không rõ nguồn gốc" rồi cài.

## Hoặc build bằng Android Studio
Open thư mục này > Build > Build APK(s). File ở `app/build/outputs/apk/debug/`.

## Chỉnh giao diện
Chỉ cần sửa `index.html` rồi build lại. Bản HTML cũng chạy riêng trong trình duyệt
(đọc được, nhưng không xuất MP3 được).
