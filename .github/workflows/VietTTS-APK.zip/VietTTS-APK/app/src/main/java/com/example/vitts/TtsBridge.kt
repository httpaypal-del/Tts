package com.example.vitts

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Cầu nối giữa giao diện HTML (JavaScript) và engine TTS + bộ mã hóa MP3 của Android.
 * HTML gọi: Android.play(...), Android.exportMp3(...), ...
 * Android trả sự kiện về: window.onNative({type: "...", ...})
 */
class TtsBridge(private val activity: MainActivity, private val web: WebView) : TextToSpeech.OnInitListener {

    private val app = activity.applicationContext
    private val tts = TextToSpeech(app, this)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val waiters = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    @Volatile private var ready = false
    @Volatile private var langMissing = false
    @Volatile private var chunks: List<Chunk> = emptyList()
    @Volatile private var currentIndex = 0
    private var nextEnqueue = 0
    private var exportJob: Job? = null

    private val maxLen: Int get() = minOf(400, TextToSpeech.getMaxSpeechInputLength() - 1)

    private fun emit(type: String, data: JSONObject = JSONObject()) {
        data.put("type", type)
        val js = "window.onNative && window.onNative($data)"
        web.post { web.evaluateJavascript(js, null) }
    }

    // ---------- Khởi tạo ----------
    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            emit("error", JSONObject().put("message", "Không khởi tạo được bộ đọc giọng nói (TTS)"))
            return
        }
        tts.setOnUtteranceProgressListener(listener)
        val r = tts.setLanguage(Locale("vi", "VN"))
        langMissing = r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED
        ready = true
        emitReady()
    }

    private fun emitReady() {
        val voices = (tts.voices ?: emptySet())
            .filter { it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true }
            .sortedWith(compareBy({ !it.locale.toLanguageTag().startsWith("vi") }, { it.locale.toLanguageTag() }, { it.name }))
        val arr = JSONArray()
        voices.forEach { arr.put(JSONObject().put("name", it.name).put("locale", it.locale.toLanguageTag())) }
        emit("ready", JSONObject()
            .put("voices", arr)
            .put("selected", tts.voice?.name ?: voices.firstOrNull()?.name ?: "")
            .put("langMissing", langMissing))
    }

    @JavascriptInterface fun init() { if (ready) emitReady() }

    @JavascriptInterface
    fun installVoiceData() {
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
            } catch (e: Exception) {
                emit("error", JSONObject().put("message", "Vào Cài đặt > Ngôn ngữ > Chuyển văn bản thành giọng nói để cài giọng đọc"))
            }
        }
    }

    // ---------- Tệp / clipboard ----------
    @JavascriptInterface fun pickFile() = activity.pickFile()

    fun loadFile(uri: Uri) {
        scope.launch {
            try {
                val text = app.contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use { it.readText() }
                emit("file", JSONObject().put("text", text))
            } catch (e: Exception) {
                emit("error", JSONObject().put("message", "Không đọc được file: ${e.message}"))
            }
        }
    }

    @JavascriptInterface
    fun getClipboard(): String {
        val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(app)?.toString().orEmpty()
    }

    @JavascriptInterface
    fun openFile(uri: String) {
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), "audio/mpeg")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (e: Exception) {
                emit("error", JSONObject().put("message", "Không có ứng dụng nghe nhạc để mở file"))
            }
        }
    }

    @JavascriptInterface
    fun shareFile(uri: String) {
        activity.runOnUiThread {
            val send = Intent(Intent.ACTION_SEND).setType("audio/mpeg")
                .putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            activity.startActivity(Intent.createChooser(send, "Chia sẻ MP3"))
        }
    }

    // ---------- Phát ----------
    private fun applyParams(voice: String?, rate: Double, pitch: Double) {
        tts.setSpeechRate(rate.toFloat())
        tts.setPitch(pitch.toFloat())
        if (!voice.isNullOrEmpty()) tts.voices?.firstOrNull { it.name == voice }?.let { tts.voice = it }
    }

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(id: String) {
            if (!id.startsWith("c")) return
            val k = id.drop(1).toInt()
            currentIndex = k
            enqueueUpTo(k + 3)
            chunks.getOrNull(k)?.let {
                emit("start", JSONObject().put("start", it.start).put("end", it.start + it.text.length))
            }
        }

        override fun onRangeStart(id: String, start: Int, end: Int, frame: Int) {
            if (!id.startsWith("c")) return
            val c = chunks.getOrNull(id.drop(1).toInt()) ?: return
            emit("range", JSONObject().put("start", c.start + start).put("end", c.start + end))
        }

        override fun onDone(id: String) {
            waiters.remove(id)?.complete(true)
            if (id.startsWith("c") && id.drop(1).toInt() == chunks.lastIndex) {
                currentIndex = 0
                emit("done")
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onError(id: String?) { onError(id, -1) }

        override fun onError(id: String?, errorCode: Int) {
            id ?: return
            waiters.remove(id)?.complete(false)
            if (id.startsWith("c")) emit("error", JSONObject().put("message", "Lỗi khi đọc (mã $errorCode)").put("stop", true))
        }
    }

    @Synchronized
    private fun enqueueUpTo(limit: Int) {
        while (nextEnqueue < chunks.size && nextEnqueue <= limit) {
            tts.speak(chunks[nextEnqueue].text, TextToSpeech.QUEUE_ADD, null, "c$nextEnqueue")
            nextEnqueue++
        }
    }

    private fun speakFrom(index: Int) {
        tts.stop()
        nextEnqueue = index
        enqueueUpTo(index + 2)
    }

    @JavascriptInterface
    fun play(text: String, voice: String, rate: Double, pitch: Double) {
        applyParams(voice, rate, pitch)
        chunks = TextChunker.split(text, maxLen)
        currentIndex = 0
        if (chunks.isEmpty()) emit("done") else speakFrom(0)
    }

    @JavascriptInterface fun pause() { tts.stop() }

    @JavascriptInterface
    fun resume(voice: String, rate: Double, pitch: Double) {
        applyParams(voice, rate, pitch)
        speakFrom(currentIndex)
    }

    @JavascriptInterface fun stop() { tts.stop(); currentIndex = 0 }

    // ---------- Xuất MP3 ----------
    private suspend fun synthToWav(text: String, id: String, file: File): Boolean {
        val d = CompletableDeferred<Boolean>()
        waiters[id] = d
        val r = tts.synthesizeToFile(text, null, file, id)
        if (r != TextToSpeech.SUCCESS) { waiters.remove(id); return false }
        return try { d.await() } finally { waiters.remove(id) }
    }

    @JavascriptInterface
    fun exportMp3(text: String, voice: String, rate: Double, pitch: Double, bitrate: Int) {
        if (exportJob?.isActive == true) return
        tts.stop()
        applyParams(voice, rate, pitch)
        val list = TextChunker.split(text, maxLen)
        if (list.isEmpty()) { emit("exportError", JSONObject().put("message", "Chưa có văn bản để xuất")); return }
        val name = "tts_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp3"

        exportJob = scope.launch {
            var created: Uri? = null
            var outRef: OutputStream? = null
            try {
                val target = Mp3Storage.create(app, name)
                created = target
                val out = app.contentResolver.openOutputStream(target)!!.buffered(64 * 1024)
                outRef = out
                var encoder: Mp3Encoder? = null
                for ((i, ch) in list.withIndex()) {
                    ensureActive()
                    val wav = File(app.cacheDir, "tts_part_$i.wav")
                    try {
                        if (!synthToWav(ch.text, "e$i", wav)) error("Bộ đọc giọng nói báo lỗi ở đoạn ${i + 1}")
                        val info = WavReader.parse(wav) ?: error("Không đọc được dữ liệu âm thanh")
                        if (encoder == null) encoder = Mp3Encoder(info.sampleRate, info.channels, bitrate, out)
                        encoder.encodeWav(wav, info)
                    } finally {
                        wav.delete()
                    }
                    emit("progress", JSONObject().put("value", (i + 1.0) / list.size))
                }
                encoder?.finish()
                out.close()
                Mp3Storage.publish(app, target)
                emit("exported", JSONObject().put("uri", target.toString()).put("name", name))
            } catch (e: CancellationException) {
                withContext(NonCancellable) {
                    runCatching { outRef?.close() }
                    created?.let { Mp3Storage.delete(app, it) }
                }
                emit("cancelled")
                throw e
            } catch (e: Exception) {
                runCatching { outRef?.close() }
                created?.let { Mp3Storage.delete(app, it) }
                emit("exportError", JSONObject().put("message", e.message ?: "Lỗi không xác định"))
            }
        }
    }

    @JavascriptInterface
    fun cancelExport() {
        tts.stop()
        exportJob?.cancel()
    }

    fun shutdown() {
        scope.cancel()
        tts.stop()
        tts.shutdown()
    }
}
