package com.example.vitts

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

class WavInfo(val sampleRate: Int, val channels: Int, val bits: Int, val dataOffset: Long, val dataSize: Long)

object WavReader {
    /** Đọc header WAV do TextToSpeech.synthesizeToFile() tạo ra (PCM 16-bit). */
    fun parse(file: File): WavInfo? = try {
        RandomAccessFile(file, "r").use { raf ->
            val head = ByteArray(12)
            raf.readFully(head)
            if (String(head, 0, 4) != "RIFF" || String(head, 8, 4) != "WAVE") return null
            var channels = 1
            var rate = 22050
            var bits = 16
            while (raf.filePointer + 8 <= raf.length()) {
                val idBytes = ByteArray(4)
                raf.readFully(idBytes)
                val sizeBytes = ByteArray(4)
                raf.readFully(sizeBytes)
                val size = ByteBuffer.wrap(sizeBytes).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
                when (String(idBytes)) {
                    "fmt " -> {
                        val b = ByteArray(size.toInt())
                        raf.readFully(b)
                        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
                        bb.short // audioFormat
                        channels = bb.short.toInt()
                        rate = bb.int
                        bb.int; bb.short // byteRate, blockAlign
                        bits = bb.short.toInt()
                        if (size % 2 == 1L) raf.skipBytes(1)
                    }
                    "data" -> {
                        val offset = raf.filePointer
                        val avail = raf.length() - offset
                        // Một số engine ghi size = 0 hoặc 0xFFFFFFFF: đọc đến hết file
                        val dsize = if (size <= 0 || size > avail) avail else size
                        return WavInfo(rate, channels, bits, offset, dsize)
                    }
                    else -> raf.seek(raf.filePointer + size + (size and 1))
                }
            }
            null
        }
    } catch (e: Exception) {
        null
    }
}
