package com.example.vitts

data class Chunk(val start: Int, val text: String)

/** Chia văn bản dài thành các đoạn nhỏ (ưu tiên cắt ở cuối câu) để TTS không bị giới hạn độ dài. */
object TextChunker {
    private const val STRONG = ".!?…。\n"
    private const val WEAK = ",;:， "

    fun split(text: String, maxLen: Int): List<Chunk> {
        val result = mutableListOf<Chunk>()
        var i = 0
        val n = text.length
        while (i < n) {
            var end = minOf(i + maxLen, n)
            if (end < n) {
                val low = i + maxLen / 2
                var cut = -1
                for (k in end - 1 downTo low) if (text[k] in STRONG) { cut = k + 1; break }
                if (cut == -1) for (k in end - 1 downTo low) if (text[k] in WEAK) { cut = k + 1; break }
                if (cut != -1) end = cut
            }
            val piece = text.substring(i, end)
            if (piece.isNotBlank()) result += Chunk(i, piece)
            i = end
        }
        return result
    }
}
