package com.example.vitts

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : ComponentActivity() {

    private lateinit var bridge: TtsBridge

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { bridge.loadFile(it) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        bridge = TtsBridge(this, web)
        web.addJavascriptInterface(bridge, "Android")
        setContentView(web)

        // Android 15 bắt buộc edge-to-edge: chừa chỗ cho thanh trạng thái / thanh điều hướng
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    fun pickFile() = runOnUiThread { picker.launch(arrayOf("text/plain")) }

    override fun onDestroy() {
        bridge.shutdown()
        super.onDestroy()
    }
}
