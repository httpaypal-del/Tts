package com.example.vitts

import com.naman14.androidlame.AndroidLame
import com.naman14.androidlame.LameBuilder
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Mã hóa nhiều file WAV nối tiếp nhau thành một luồng MP3 duy nhất. */
class Mp3Encoder(sampleRate: Int, private val channels: Int, bitrateKbps: Int, private val out: OutputStream) {

    private val lame: AndroidLame = LameBuilder()
        .setInSampleRate(sampleRate)
        .setOutChannels(channels)
        .setOutBitrate(bitrateKbps)
        .setOutSampleRate(sampleRate)
        .build()

    private val mp3Buf = ByteArray(24000)

    fun encodeWav(file: File, info: WavInfo) {
        require(info.bits == 16) { "Chỉ hỗ trợ PCM 16-bit" }
        val frames = 4096
        val raw = ByteArray(frames * channels * 2)
        var remaining = info.dataSize
        FileInputStream(file).use { input ->
            input.channel.position(info.dataOffset)
            while (remaining > 0) {
                val want = minOf(raw.size.toLong(), remaining).toInt()
                val n = readFill(input, raw, want)
                if (n <= 0) break
                val samples = n / (2 * channels)
                if (samples == 0) break
                val sb = ByteBuffer.wrap(raw, 0, n).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                val left = ShortArray(samples)
                val right = if (channels == 2) ShortArray(samples) else left
                for (i in 0 until samples) {
                    left[i] = sb.get()
                    if (channels == 2) right[i] = sb.get()
                }
                val encoded = lame.encode(left, right, samples, mp3Buf)
                if (encoded > 0) out.write(mp3Buf, 0, encoded)
                remaining -= n
            }
        }
    }

    fun finish() {
        val n = lame.flush(mp3Buf)
        if (n > 0) out.write(mp3Buf, 0, n)
        lame.close()
    }

    private fun readFill(input: InputStream, buf: ByteArray, len: Int): Int {
        var total = 0
        while (total < len) {
            val r = input.read(buf, total, len - total)
            if (r < 0) break
            total += r
        }
        return total
    }
}
